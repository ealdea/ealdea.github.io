#pragma once
#include <iostream>


class telemetre{
	private :
	
	double mesure; 
	unsigned int cat;
	
	public :  
	
	void setCat(unsigned int val);
	
	unsigned int getCat() const; 
	
	telemetre();
	
	telemetre(unsigned int);
	
	telemetre(const telemetre& param);
	
	~telemetre();
};

