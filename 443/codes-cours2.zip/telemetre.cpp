#include <iostream>
#include "telemetre.h"

void telemetre::setCat(unsigned int val){
	//check
		
	if(val > 3){
		std::cout << " lisez le manuel " << std::endl;
		return;
	}
	cat = val;
}
	
unsigned int telemetre::getCat() const {
	//mesure = 30;
	return cat;
} 
	
telemetre::telemetre(){
	std::cout << " telemetre() " << std::endl;
	cat = 1;
	mesure = 0;
}

telemetre::telemetre(unsigned int param){
	std::cout << " telemetre(unsigned int) " << std::endl;
	cat = param;
	mesure = 0;
}


telemetre::telemetre(const telemetre& param){
	cat = param.cat;
	mesure = param.mesure;
	std::cout << " telemetre(telemetre&) " << std::endl;
}

telemetre::~telemetre(){
	std::cout << " ~telemetre() " << std::endl;
}

