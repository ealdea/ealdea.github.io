#include "telemetre.h"
#include <iostream>



int main(){

	
	telemetre toto(2);
	
	
	
	telemetre titi(toto);
	
	//toto.setCat(2);
	
	
	std::cout << titi.getCat() << std::endl;
	
	
	return 0;
}
