#include <iostream>

using namespace std;

class Parent{

	public : 
	
	Parent(){
		cout << "Parent()" << endl;
	}
	
	virtual void print(){
		cout << "print() du Parent" << endl;
	}
	
	void methodeParent(){
		print();
	}

};

class Enfant : public Parent{
	public : 
	
	Enfant(){
		cout << "Enfant()" << endl;
	}
	
	
	void print(){
		cout << "print() de l'Enfant" << endl;
	}
	
	
	void grosCalcul(){
		print();
	}
	

};

class Capteur{
	public:  
	virtual void init(){
		cout << "init() Capteur : alim OK" << endl;
	}

};

class Lidar : public Capteur{
	public:  
	void init(){
		cout << "init() Lidar : allocation memoire" << endl;
	}

};

class Camera : public Capteur{
	public:  
	void init(){
		cout << "init() Camera : demande image" << endl;
	}

};

class Ultrason : public Capteur{
	public:  
	void init(){
		cout << "init() Ultrason : emission" << endl;
	}

};



int main(){

	Lidar l;
	Camera c;
	Ultrason u;
	
	/*
	l.init();
	c.init();
	u.init();
	*/
	
	Capteur* tab[3];
	tab[0] = &l;
	tab[1] = &c;
	tab[2] = &u;
	
	for(int i = 0; i < 3; i++)
		tab[i]->init();

	
	Enfant e;
	e.grosCalcul();
	e.methodeParent();
	
	
	
	
	/*
	Parent* ptr = (Parent*) &e;
	
	ptr->print();
	*/	
	return 0;
}
