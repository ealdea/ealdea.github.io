#include <iostream>
using namespace std;

class A
{
public:
	A() {}
	virtual ~A(){}
};

class B: public A
{
	double* tab;
public:
	B():A(){ tab = new double[1000000];}
	~B(){delete[] tab;}
};

int main(void)
{
  A* a = new B();
  delete a;
  return 0;
}
