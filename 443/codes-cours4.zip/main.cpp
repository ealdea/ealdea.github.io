#include<iostream>
class A{

	double d;
	
	
	protected :
	
	
	
	public :
	
	static float f;
	
	void print(){
		std::cout << "gros calcul " << f << std::endl;
	}
	 
	A(){
		std::cout << "constr A()" << std::endl;
		d = 17;
		print();
	}
	
	public : 
};

float A::f = 5.0;


/*
//version composition de classes
class B{

	A membre;
	int x;

};
*/


//version heritage
class B : public A {
	int x;
	
	float* tab;
	
	public : 
	B(){
		tab = new float[10000];
		std::cout << "constr B()" << std::endl;
	}
	
	void fc(){
		
		std::cout << "methode tres compliquee en B" << tab[5000] << std::endl;
	}
	
	/*
	~B(){
		delete[] tab;
	}
	*/

};



int main(){
	
	A obj;
	
	A* ptr = &obj;
	B* ptr2 = (B*)ptr;
	
	
	
	
	
	/*
	ptr2->fc();
	 
	std::cout << ptr << std::endl;
	std::cout << ptr2 << std::endl;
	
	ptr2->print();
	*/
	
	B ranya;
	B* pranya = &ranya;
	pranya->fc();
	
	std::cout << "partie 2" << std::endl;
	
	
	
	B b;
	
	A a(b);
	
	
	
	return 0;
}




