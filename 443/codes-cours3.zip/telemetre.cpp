#include <iostream>
#include "telemetre.h"

void telemetre::setCat(unsigned int val){
	//check
		
	if(val > 3){
		std::cout << " lisez le manuel " << std::endl;
		return;
	}
	cat = val;
	
	checkObj();
}
	
bool telemetre::checkObj() const{

	if(mesure < 0){
		std::cout << " votre telemetre ne fonctionne plus bien" << std::endl;
		return false;
	}
	else
		return true;
}	

unsigned int telemetre::getCat() const {
	//mesure = 30;
	checkObj();
	return cat;
} 

	
telemetre::telemetre() : telemetre(1) {

	std::cout << " telemetre() " << std::endl;
	checkObj();
}

telemetre::telemetre(unsigned int param) : cat(param), mesure(1.6){
	std::cout << " telemetre(unsigned int) " << std::endl;
}


telemetre::telemetre(const telemetre& param){
	cat = param.cat;
	mesure = param.mesure;
	std::cout << " telemetre(telemetre&) " << std::endl;
}

telemetre::~telemetre(){
	std::cout << " ~telemetre() " << std::endl;
}


telemetre& telemetre::operator = (const telemetre& param){
	if(this != &param){
		cat = param.cat;
		mesure = param.mesure;
	}
	std::cout << " operator = (telemetre&) " << std::endl;
	return *this;
}


double telemetre::operator + (const telemetre& param) const {
	return mesure + param.mesure;
}


ostream& operator << (ostream& os, const telemetre& param){
	os << "categorie = " << param.cat << " ; mesure = " << param.mesure << endl;
	return os;
}


/*
void telemetre::print(){
	cout << "categorie = " << cat << " ; mesure = " << mesure << endl;
	 
}
*/



