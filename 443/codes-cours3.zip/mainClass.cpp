#include "telemetre.h"
#include <iostream>


class A{

	public : 
	
	A(int param1, int param2){
		int local = param1 + param2;
	}

};

class B{
	private :
	A a;
	
	public : 
	
	B(): a(2,3) {
	
	}
	
};



int main(){

	B obj;
	
	
	telemetre a,b,c;
	
	b = a;
	
	double val = b + a;
	
	int x = 5, y = 6;
	
	//if(a < b)  
	std::cout << val << " ; " << x << " ; " << y << " ; " << b << std::endl;
	
	
	//std::cout << b << std::endl;
	//b.print();
	
	int* tab = new int;
	
	//tab[0] = 5;
	*tab= 5;
	//*tab = 5;
	
	cout << tab[0] << endl;
	//cout << *(tab+2) << endl;
	
	
	return 0;
}
