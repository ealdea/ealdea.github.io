#pragma once
#include <iostream>

using namespace std;


class telemetre{
	private :
	
	short int test;
	
	double mesure; 
	unsigned int cat;
	
	void setCat(unsigned int val);
	
	bool checkObj() const;
	
	
	telemetre(unsigned int);
	
	
	public :  
	
	
	unsigned int getCat() const;
	
	telemetre();
	
	double operator + (const telemetre& param) const;
	
	
	telemetre& operator = (const telemetre& param);
	
	telemetre(const telemetre& param);

	operator int() { return cat; }
	
	friend ostream& operator << (ostream& os, const telemetre& param);
	
	//operator double() { return mesure; }	
	
	//void print();
	
	~telemetre();
};

