import sys
import os
import numpy as np
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torch
from torch import nn
import torch.nn.functional as F

from torchmetrics import Accuracy
from tqdm.notebook import tqdm

sys.path.append(os.getcwd())

from torch import nn


#### ici ce sera pour definir vos modeles unimodaux simples de type LeNet
#voici un exemple pour vous aider à demarrer


class LeNetV2(nn.Module):
    def __init__(self):
        super().__init__()
        self.feature = nn.Sequential(
            #1
            nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=2),   # 28*28->32*32-->28*28
            nn.Tanh(),
            nn.AvgPool2d(kernel_size=2, stride=2),  # 14*14

            #2
            nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1),  # 10*10
            nn.Tanh(),
            nn.AvgPool2d(kernel_size=2, stride=2),  # 5*5

        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(in_features=16*5*5, out_features=120),
            nn.Tanh(),
            nn.Linear(in_features=120, out_features=84),
            nn.Tanh(),
            nn.Linear(in_features=84, out_features=10),
        )

    def forward(self, x):
        return self.classifier(self.feature(x))


#####  d'autres modeles : ici   TODO


#### chargement des donnees audio et video

data_dir = '../../av-mnist/avmnist' # a changer eventuellement
batch_size=40
num_workers=8
train_shuffle=True
flatten_audio=False
flatten_image=False
unsqueeze_channel=True
generate_sample=True
normalize_image=True
normalize_audio=True


traindata = [np.load(data_dir+"/image/train_data.npy"), np.load(data_dir +
                                                                 "/audio/train_data.npy"), np.load(data_dir+"/train_labels.npy")]
testdata = [np.load(data_dir+"/image/test_data.npy"), np.load(data_dir +
                                                               "/audio/test_data.npy"), np.load(data_dir+"/test_labels.npy")]
if flatten_audio:
    traindata[1] = traindata[1].reshape(60000, 112*112)
    testdata[1] = testdata[1].reshape(10000, 112*112)




if normalize_image:
    traindata[0] /= 255.0
    testdata[0] /= 255.0
if normalize_audio:
    traindata[1] = traindata[1]/255.0
    testdata[1] = testdata[1]/255.0
if not flatten_image:
    traindata[0] = traindata[0].reshape(60000, 28, 28)
    testdata[0] = testdata[0].reshape(10000, 28, 28)
if unsqueeze_channel:
    traindata[0] = np.expand_dims(traindata[0], 1)
    testdata[0] = np.expand_dims(testdata[0], 1)
    traindata[1] = np.expand_dims(traindata[1], 1)
    testdata[1] = np.expand_dims(testdata[1], 1)


traindata[2] = traindata[2].astype(int)
testdata[2] = testdata[2].astype(int)


trainlist = [[traindata[j][i] for j in range(3)] for i in range(60000)]
testlist = [[testdata[j][i] for j in range(3)] for i in range(10000)]


#######################

#### TODO  : afficher quelques images et les annotations

#######################


validdata = DataLoader(trainlist[55000:60000], shuffle=False,
                        num_workers=num_workers, batch_size=batch_size)
testdata = DataLoader(testlist, shuffle=False,
                       num_workers=num_workers, batch_size=batch_size)
traindata = DataLoader(trainlist[0:55000], shuffle=train_shuffle,
                        num_workers=num_workers, batch_size=batch_size)


model = TODO
#entrainez et evaluez pour chaque modalité et ensemble

